export const handler = async (event, context) => {
  console.log("** LAMBDA EVENT **")

  console.log(event)
}
